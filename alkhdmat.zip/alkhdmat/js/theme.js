const mobToggleBtn = document.querySelectorAll('.menu-item-has-children');
mobToggleBtn.forEach(ele => ele.addEventListener('click', function() {
    ele.querySelector('.mobile-menu ul.menu > li.menu-item-has-children > ul.sub-menu').classList.toggle("active");
}));

