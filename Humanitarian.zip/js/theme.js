var content1 = document.getElementById("card_content_1");
var content2 = document.getElementById("card_content_2");
var content3 = document.getElementById("card_content_3");
var content4 = document.getElementById("card_content_4");
var content5 = document.getElementById("card_content_5");
var content6 = document.getElementById("card_content_6");
var content7 = document.getElementById("card_content_7");
var content8 = document.getElementById("card_content_8");
var btn1 = document.getElementById("btn1");
var btn2 = document.getElementById("btn2");
var btn3 = document.getElementById("btn3");
var btn4 = document.getElementById("btn4");

function openClassOne(){
	content1.style.transform = "translate(0, -50%)";
	content2.style.transform = "translate(112%, -50%)";
	content3.style.transform = "translate(112%, -50%)";
	content4.style.transform = "translate(112%, -50%)";
	content5.style.transform = "translate(112%, -50%)";
	content6.style.transform = "translate(112%, -50%)";
	content7.style.transform = "translate(112%, -50%)";
	content8.style.transform = "translate(112%, -50%)";
	content1.style.transitionDelay = "0.5s";
	content2.style.transitionDelay = "0";
	content3.style.transitionDelay = "0";
	content4.style.transitionDelay = "0";
	content5.style.transitionDelay = "0";
	content6.style.transitionDelay = "0";
	content7.style.transitionDelay = "0";
	content8.style.transitionDelay = "0";
}
function openClassTwo(){	
	content1.style.transform = "translate(112%, -50%)";
	content2.style.transform = "translate(0, -50%)";
	content3.style.transform = "translate(112%, -50%)";
	content4.style.transform = "translate(112%, -50%)";
	content5.style.transform = "translate(112%, -50%)";
	content6.style.transform = "translate(112%, -50%)";
	content7.style.transform = "translate(112%, -50%)";
	content8.style.transform = "translate(112%, -50%)";
	content2.style.transitionDelay = "0.5s";
	content1.style.transitionDelay = "0";
	content3.style.transitionDelay = "0";
	content4.style.transitionDelay = "0";
	content5.style.transitionDelay = "0";
	content6.style.transitionDelay = "0";
	content7.style.transitionDelay = "0";
	content8.style.transitionDelay = "0";
}
function openClassThree(){
	content1.style.transform = "translate(112%, -50%)";
	content2.style.transform = "translate(112%, -50%)";
	content3.style.transform = "translate(0, -50%)";
	content4.style.transform = "translate(112%, -50%)";
	content5.style.transform = "translate(112%, -50%)";
	content6.style.transform = "translate(112%, -50%)";
	content7.style.transform = "translate(112%, -50%)";
	content8.style.transform = "translate(112%, -50%)";
	content3.style.transitionDelay = "0.5s";
	content1.style.transitionDelay = "0";
	content2.style.transitionDelay = "0";
	content4.style.transitionDelay = "0";
	content5.style.transitionDelay = "0";
	content6.style.transitionDelay = "0";
	content7.style.transitionDelay = "0";
	content8.style.transitionDelay = "0";
}
function openClassFour(){
	content1.style.transform = "translate(112%, -50%)";
	content2.style.transform = "translate(112%, -50%)";
	content3.style.transform = "translate(112%, -50%)";
	content4.style.transform = "translate(0, -50%)";
	content5.style.transform = "translate(112%, -50%)";
	content6.style.transform = "translate(112%, -50%)";
	content7.style.transform = "translate(112%, -50%)";
	content8.style.transform = "translate(112%, -50%)";
	content4.style.transitionDelay = "0.5s";
	content3.style.transitionDelay = "0";
	content2.style.transitionDelay = "0";
	content1.style.transitionDelay = "0";
	content5.style.transitionDelay = "0";
	content6.style.transitionDelay = "0";
	content7.style.transitionDelay = "0";
	content8.style.transitionDelay = "0";
}

function openClassFive(){
	content1.style.transform = "translate(112%, -50%)";
	content2.style.transform = "translate(112%, -50%)";
	content3.style.transform = "translate(112%, -50%)";
	content4.style.transform = "translate(112%, -50%)";
	content5.style.transform = "translate(0, -50%)";
	content6.style.transform = "translate(112%, -50%)";
	content7.style.transform = "translate(112%, -50%)";
	content8.style.transform = "translate(112%, -50%)";
	content5.style.transitionDelay = "0.5s";
	content2.style.transitionDelay = "0";
	content3.style.transitionDelay = "0";
	content4.style.transitionDelay = "0";
	content1.style.transitionDelay = "0";
	content6.style.transitionDelay = "0";
	content7.style.transitionDelay = "0";
	content8.style.transitionDelay = "0";
}

function openClassSix(){
	content1.style.transform = "translate(112%, -50%)";
	content2.style.transform = "translate(112%, -50%)";
	content3.style.transform = "translate(112%, -50%)";
	content4.style.transform = "translate(112%, -50%)";
	content5.style.transform = "translate(112%, -50%)";
	content6.style.transform = "translate(0, -50%)";
	content7.style.transform = "translate(112%, -50%)";
	content8.style.transform = "translate(112%, -50%)";
	content6.style.transitionDelay = "0.5s";
	content2.style.transitionDelay = "0";
	content3.style.transitionDelay = "0";
	content4.style.transitionDelay = "0";
	content5.style.transitionDelay = "0";
	content1.style.transitionDelay = "0";
	content7.style.transitionDelay = "0";
	content8.style.transitionDelay = "0";
}

function openClassSeven(){
	content1.style.transform = "translate(112%, -50%)";
	content2.style.transform = "translate(112%, -50%)";
	content3.style.transform = "translate(112%, -50%)";
	content4.style.transform = "translate(112%, -50%)";
	content5.style.transform = "translate(112%, -50%)";
	content6.style.transform = "translate(112%, -50%)";
	content7.style.transform = "translate(0, -50%)";
	content8.style.transform = "translate(112%, -50%)";
	content7.style.transitionDelay = "0.5s";
	content2.style.transitionDelay = "0";
	content3.style.transitionDelay = "0";
	content4.style.transitionDelay = "0";
	content5.style.transitionDelay = "0";
	content6.style.transitionDelay = "0";
	content1.style.transitionDelay = "0";
	content8.style.transitionDelay = "0";
}

function openClassEight(){
	content1.style.transform = "translate(112%, -50%)";
	content2.style.transform = "translate(112%, -50%)";
	content3.style.transform = "translate(112%, -50%)";
	content4.style.transform = "translate(112%, -50%)";
	content5.style.transform = "translate(112%, -50%)";
	content6.style.transform = "translate(112%, -50%)";
	content7.style.transform = "translate(112%, -50%)";
	content8.style.transform = "translate(0, -50%)";
	content8.style.transitionDelay = "0.5s";
	content2.style.transitionDelay = "0";
	content3.style.transitionDelay = "0";
	content4.style.transitionDelay = "0";
	content5.style.transitionDelay = "0";
	content6.style.transitionDelay = "0";
	content7.style.transitionDelay = "0";
	content1.style.transitionDelay = "0";
}

// step 1 


$(document).ready(function(){
	$('.map_info_main').slick({
		infinite: true,
		slidesToShow: 2,
		slidesToScroll: 1,
		infinite: false,
		speed: 2500,
		autoplay: true,
		prevArrow: '<i class="fa-solid fa-chevron-left slick-prev"><img src="img/left_arrow.png" /></i>',
		nextArrow: '<i class="fa-solid fa-chevron-right slick-next"><img src="img/right_arrow.png" /></i>',
		responsive: [
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 2,
				infinite: true,
				dots: true
			  }
			},
			{
			  breakpoint: 600,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 480,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		  ]
	  });
})


// step 2 


$(document).ready(function(){
	$('.Country_sliders').slick({
		infinite: true,
		slidesToShow: 1,
		slidesToScroll: 1,
		arrows: false,
		infinite: false,
		speed: 2000,
		autoplay: true,
  		autoplaySpeed: 2000,
		responsive: [
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
				infinite: true,
				dots: true
			  }
			},
			{
			  breakpoint: 600,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 480,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		  ]
	  });
})


// step 3 


$(document).ready(function(){
	$('.slider_step_3').slick({
		infinite: true,
		slidesToShow: 1,
		slidesToScroll: 1,
		arrows: true,
		infinite: false,
		speed: 2000,
		autoplay: true,
  		autoplaySpeed: 20000,
		prevArrow: '<i class="fa-solid fa-chevron-left slick-prev"><img src="img/left_arrow.png" /></i>',
		nextArrow: '<i class="fa-solid fa-chevron-right slick-next"><img src="img/right_arrow.png" /></i>',
		responsive: [
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
				infinite: true,
				dots: true
			  }
			},
			{
			  breakpoint: 600,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 480,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		  ]
	  });
})

$(document).ready(function() {
    $('img').each(function() {
        var $img = $(this);
        var filename = $img.attr('src').replace(new RegExp("-", "g"), ' ');
        var filename1 = filename.substring(filename.lastIndexOf('/')+1);    
        var attr = $(this).attr('alt');
        var title = $(this).attr('title');    

        if (typeof attr == typeof undefined || attr == false) {
            $img.attr('alt', filename1.substring(0, filename1.indexOf('.')));
        }
    });
});

